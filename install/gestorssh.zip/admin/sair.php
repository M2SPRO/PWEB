<?php
// Inclui o arquivo com o sistema de segurança
require_once("../pages/system/seguranca.php");
expulsaSair();
?>
